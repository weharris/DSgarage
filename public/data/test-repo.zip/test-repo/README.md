This test-project is part of a Github tutorial at the Data Science Garage Bootcamp

https://dsgarage.netlify.app/bootcamp/